  <!-- Bootstrap bundle JS -->
  <script src="admin/assets/js/bootstrap.bundle.min.js"></script>
  <!--plugins-->
  <script src="admin/assets/js/jquery.min.js"></script>
  <script src="admin/assets/plugins/simplebar/js/simplebar.min.js"></script>
  <script src="admin/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
  <script src="admin/assets/js/pace.min.js"></script>
  <!-- <script src="admin/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script> -->
  <script src="admin/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
  <script src="admin/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
  <!--app-->
  <script src="admin/assets/js/app.js"></script>
  <script src="admin/assets/js/index.js"></script>
  <!-- <script src="assets/js/clock.js"></script> -->
  <script src="admin/assets/js/clock_ad.js"></script>
  <!-- <script src="admin/assets/js/ajaxPerforms.js"></script> -->

  <script>
new PerfectScrollbar(".best-product")
new PerfectScrollbar(".top-sellers-list")
  </script>


  <?php
   
    if(isset($_SESSION['status_ad']) && $_SESSION['status_ad']!=''){ ?>
  <script>
Swal.fire({
  icon: '<?php echo $_SESSION['icon_ad'] ?>',
  title: '<?php echo $_SESSION['status_ad'] ?>',
  showCloseButton: true,
  confirmButton: true,

})
  </script>
  <?php
unset($_SESSION['status_ad']);
unset($_SESSION['icon_ad']);
// session_destroy();
}?>
  <script>
function dataSet(processName, dataSet) {
  var formData = new FormData();
  switch (processName) {
    case 'branchEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'branchView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'branchDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'deptEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'deptView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'deptDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdeptEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdeptView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdeptDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'desigEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'desigView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'desigDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdesigEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdesigView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdesigDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'divisionEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'divisionView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'divisionDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdivEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdivView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'subdivDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empcatEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empcatView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empcatDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empsubcatEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empsubcatView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empsubcatDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'emptypeEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'emptypeView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'emptypeDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'gradeEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'gradeView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'gradeDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'locaEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'locaView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'locaDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'teamEdit':
      formData.append(processName + "Code", dataSet);
      break;
    case 'teamView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'teamDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'shiftEdit':
      formData.append(processName + "Code", dataSet);
      // console.log(dataSet);
      break;
    case 'shiftView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'shiftDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empEdit':
      formData.append(processName + "Code", dataSet);
      // console.log(dataSet);
      break;
    case 'empView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'empDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'userEdit':
      formData.append(processName + "Code", dataSet);
      // console.log(dataSet);
      break;
    case 'userView':
      formData.append(processName + "Code", dataSet);
      break;
    case 'userDel':
      formData.append(processName + "Code", dataSet);
      break;
    case 'userReset':
      formData.append(processName + "Code", dataSet);
      break;


  }
  return formData;
}

document.addEventListener("DOMContentLoaded", function() {
  // Attach the click event listener to a parent element
  document.addEventListener('click', function(event) {
    // Check if the clicked element has the class 'info-icon'
    if (event.target.classList.contains('info-icon')) {
      var infoBox = event.target.closest('.info-box'); // Find the closest '.info-box' parent
      var infoContent = infoBox.querySelector('.info-content');

      // Toggle info content visibility
      infoContent.style.display = infoContent.style.display === 'block' ? 'none' : 'block';
    } else {
      // Hide info content when user clicks outside the box
      var infoBoxes = document.querySelectorAll('.info-box');
      infoBoxes.forEach(function(infoBox) {
        var infoContent = infoBox.querySelector('.info-content');
        if (infoContent !== null) {
          infoContent.style.display = 'none';
        }
      });
    }
  });
});
  </script>

  <script src="admin/assets/js/ajax_Performen.js"></script>

  <script>
  </script>