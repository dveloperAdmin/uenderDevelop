<?php
include '../include/_session.php'; 
include '../include/_dbConnect.php';
$des="load index page";
$rem="on dashbord page";

include '../include/_audiLog.php'; 
include '../include/_licCheck.php'; 
?>
<!DOCTYPE html>
<html lang="en">

<!-- head segment  -->
<?php include 'include/_head.php';?>

<body>
  <!--start wrapper-->
  <div class="wrapper">
    <?php 
        // header & navbar 
        include 'include/_headerSection.php';

        // sidebar segment 
        include 'include/_sideBar.php'
    ?>




    <!-- mode segment  -->
    <?php include 'include/_switchMode.php';?>
  </div>

</body>

<!-- footer segment  -->
<?php include 'include/_footer_.php';?>

</html>