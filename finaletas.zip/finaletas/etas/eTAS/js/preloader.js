let loader = document.getElementById('center');
window.addEventListener("load",function(){
    loader.style.display="none";
});