<?php
include '_session.php'; 
include '_dbConnect.php';
include '_function.php';
$des="load dbBackup Uipage";
$rem="dbBackup details page";
$header="Database Backup ";
$headerDes="Database";
include '_audiLog.php';


$sql_db_size_cms = sqlsrv_fetch_array(sqlsrv_query($conn, "	SELECT 
    SUM(TotalSpaceMB) as TotalSpaceMB
from (
    select 
        t.name as TableName,
        s.name as SchemaName,
        p.rows,
        SUM(a.total_pages) * 8 as TotalSpaceKB, 
        CAST(ROUND(((SUM(a.total_pages) * 8) / 1024.00), 2) as numeric(36, 2)) as TotalSpaceMB
     
    from 
        sys.tables t
    inner join      
        sys.indexes i on t.object_id = i.object_id
    inner join 
        sys.partitions p on i.object_id = p.object_id and i.index_id = p.index_id
    inner join 
        sys.allocation_units a on p.partition_id = a.container_id
    left outer join 
        sys.schemas s on t.schema_id = s.schema_id
    where 
        t.name not like 'dt%' 
        and t.is_ms_shipped = 0
        and i.object_id > 255 
    group by 
        t.name, s.name, p.rows
) as TotalSpaceByTable"), SQLSRV_FETCH_ASSOC);


if(isset($_POST['backup'])){
  $batFilePath = 'C:\xampp\htdocs\eTAS\backDb\run.bat';

  // Execute the .bat file
  $output = shell_exec($batFilePath);

  // Check if the output is not empty, indicating that the .bat file was executed
  if (!empty($output)) {
    $filePath = 'C:\xampp\htdocs\eTAS\backDb\db\backup_etas.bak';

    // Check if the file exists
    if (file_exists($filePath)) {
        // Set headers for file download
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
    header('Content-Length: ' . filesize($filePath));

    // Clear any output buffers to ensure clean download
    ob_clean();

    // Flush system output buffer
    flush();

    // Read the file and output its contents
    if(readfile($filePath)){
      unlink($filePath);

    }

      // Delete the file after download
    } else {
        $_SESSION['status_ad'] ="Database Not Downloaded";
        $_SESSION['icon_ad'] = "error";
    }
  } else {
        $_SESSION['status_ad'] ="Database backup Not done";
        $_SESSION['icon_ad'] = "error";
    }


}






?>

<!DOCTYPE html>
<html lang="en">

<!-- head segment  -->
<?php include '../admin/include/_head.php';?>

<body>
  <!--start wrapper-->
  <div class="wrapper">
    <?php 
      echo $sql_db_size_cms['TotalSpaceMB'];
        // header & navbar 
        include '../admin/include/_headerSection.php';

        // sidebar segment 
        include '../admin/include/_sideBar.php'
    ?>
    <!--start content-->
    <main class="page-content">
      <?php include '../admin/include/_pageHeader.php' ; ?>
      <div class="card" style="padding:1rem">
        <div class="row">
          <div class="dbBack" style="">
            <div>
              <h5 class="header-sec" id="bio_sync">
                Database Name
                :-<?php  echo"<span style='color:red; font-size: 16px;  padding-left: 2rem'>".$db_name."</span>" ?>
              </h5>
              <h5 class="header-sec" id="bio_sync">
                Database Size
                :-<?php  echo"<span style='color:red; font-size: 16px;  padding-left: 2rem'>&nbsp;".$sql_db_size_cms['TotalSpaceMB']." Mb</span>" ?>
              </h5>

            </div>
            <div class="user-entry">
              <form action="" method="post">
                <button type="submit" class="btn waves-effect waves-light btn-primary btn-outline-primary"
                  style="padding: 7px 20px; color:yellow;font-family: 'Oswald', sans-serif; font-weight: 500;"
                  name="backup"><i class="fa fa-angle-double-up" style="    font-size: 20px;margin-right: 10px;"></i>
                  Download <?php echo $db_name;?> Database</button>

              </form>

            </div>
            <!-- <div class="col-md-6" style="">
          </div> -->
          </div>
        </div>


        <!-- mode segment  -->
        <?php include '../admin/include/_switchMode.php';?>
      </div>
  </div>
  </div>
  </div>

</body>

<!-- footer segment  -->
<?php include '../admin/include/_footer_.php';?>

</html>